//>>built
define("dijit/nls/he/loading",{loadingState:"\u05d8\u05e2\u05d9\u05e0\u05d4...\u200f",errorState:"\u05d0\u05d9\u05e8\u05e2\u05d4 \u05e9\u05d2\u05d9\u05d0\u05d4"});
//# sourceMappingURL=loading.js.map