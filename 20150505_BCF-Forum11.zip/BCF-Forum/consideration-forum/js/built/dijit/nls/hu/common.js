//>>built
define("dijit/nls/hu/common",{buttonOk:"OK",buttonCancel:"M\u00e9gse",buttonSave:"Ment\u00e9s",itemClose:"Bez\u00e1r\u00e1s"});
//# sourceMappingURL=common.js.map