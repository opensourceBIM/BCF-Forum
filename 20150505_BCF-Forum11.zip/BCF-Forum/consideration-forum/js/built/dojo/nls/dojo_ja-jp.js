//>>built
define("dojo/nls/dojo_ja-jp",{"dijit/nls/loading":{loadingState:"\u30ed\u30fc\u30c9\u4e2d...",errorState:"\u30a8\u30e9\u30fc\u304c\u767a\u751f\u3057\u307e\u3057\u305f\u3002",_localized:{}},"dijit/nls/common":{buttonOk:"OK",buttonCancel:"\u30ad\u30e3\u30f3\u30bb\u30eb",buttonSave:"\u4fdd\u5b58",itemClose:"\u9589\u3058\u308b",_localized:{}}});
//# sourceMappingURL=dojo_ja-jp.js.map