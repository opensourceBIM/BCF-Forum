define('dojo/nls/dojo_ru',{
'dijit/nls/loading':{"loadingState":"Загрузка...","errorState":"Извините, возникла ошибка","_localized":{}}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Отмена","buttonSave":"Сохранить","itemClose":"Закрыть","_localized":{}}
});