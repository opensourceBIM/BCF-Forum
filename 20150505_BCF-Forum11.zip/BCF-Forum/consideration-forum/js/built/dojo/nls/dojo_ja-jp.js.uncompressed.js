define('dojo/nls/dojo_ja-jp',{
'dijit/nls/loading':{"loadingState":"ロード中...","errorState":"エラーが発生しました。","_localized":{}}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"キャンセル","buttonSave":"保存","itemClose":"閉じる","_localized":{}}
});