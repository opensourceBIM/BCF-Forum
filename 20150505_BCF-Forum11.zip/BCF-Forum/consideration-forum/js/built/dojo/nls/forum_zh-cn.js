//>>built
define("dojo/nls/forum_zh-cn",{"dijit/nls/loading":{loadingState:"\u6b63\u5728\u52a0\u8f7d...",errorState:"\u5bf9\u4e0d\u8d77\uff0c\u53d1\u751f\u4e86\u9519\u8bef",_localized:{}},"dijit/nls/common":{buttonOk:"\u786e\u5b9a",buttonCancel:"\u53d6\u6d88",buttonSave:"\u4fdd\u5b58",itemClose:"\u5173\u95ed",_localized:{}}});
//# sourceMappingURL=forum_zh-cn.js.map