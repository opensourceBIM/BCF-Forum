//>>built
define("dojo/nls/dojo_cs",{"dijit/nls/loading":{loadingState:"Prob\u00edh\u00e1 na\u010d\u00edt\u00e1n\u00ed...",errorState:"Omlouv\u00e1me se, do\u0161lo k chyb\u011b",_localized:{}},"dijit/nls/common":{buttonOk:"OK",buttonCancel:"Storno",buttonSave:"Ulo\u017eit",itemClose:"Zav\u0159\u00edt",_localized:{}}});
//# sourceMappingURL=dojo_cs.js.map