define('dojo/nls/forum_hu',{
'dijit/nls/loading':{"loadingState":"Betöltés...","errorState":"Sajnálom, hiba történt","_localized":{}}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Mégse","buttonSave":"Mentés","itemClose":"Bezárás","_localized":{}}
});