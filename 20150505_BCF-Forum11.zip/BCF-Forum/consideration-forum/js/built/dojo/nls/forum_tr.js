//>>built
define("dojo/nls/forum_tr",{"dijit/nls/loading":{loadingState:"Y\u00fckleniyor...",errorState:"\u00dczg\u00fcn\u00fcz, bir hata olu\u015ftu",_localized:{}},"dijit/nls/common":{buttonOk:"Tamam",buttonCancel:"\u0130ptal",buttonSave:"Kaydet",itemClose:"Kapat",_localized:{}}});
//# sourceMappingURL=forum_tr.js.map