define('dojo/nls/dojo_de',{
'dijit/nls/loading':{"loadingState":"Wird geladen...","errorState":"Es ist ein Fehler aufgetreten.","_localized":{}}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Abbrechen","buttonSave":"Speichern","itemClose":"Schließen","_localized":{}}
});