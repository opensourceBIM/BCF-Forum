define('dojo/nls/dojo_ROOT',{
'dijit/nls/loading':{"loadingState":"Loading...","errorState":"Sorry, an error occurred","_localized":{"ar":1,"az":1,"bg":1,"ca":1,"cs":1,"da":1,"de":1,"el":1,"es":1,"fi":1,"fr":1,"he":1,"hr":1,"hu":1,"id":1,"it":1,"ja":1,"kk":1,"ko":1,"nb":1,"nl":1,"pl":1,"pt":1,"pt-pt":1,"ro":1,"ru":1,"sk":1,"sl":1,"sv":1,"th":1,"tr":1,"uk":1,"zh":1,"zh-tw":1}}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Cancel","buttonSave":"Save","itemClose":"Close","_localized":{"ar":1,"az":1,"bg":1,"ca":1,"cs":1,"da":1,"de":1,"el":1,"es":1,"fi":1,"fr":1,"he":1,"hr":1,"hu":1,"id":1,"it":1,"ja":1,"kk":1,"ko":1,"nb":1,"nl":1,"pl":1,"pt":1,"pt-pt":1,"ro":1,"ru":1,"sk":1,"sl":1,"sv":1,"th":1,"tr":1,"uk":1,"zh":1,"zh-tw":1}}
});