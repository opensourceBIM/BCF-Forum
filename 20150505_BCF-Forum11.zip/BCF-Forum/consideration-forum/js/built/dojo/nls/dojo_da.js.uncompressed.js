define('dojo/nls/dojo_da',{
'dijit/nls/loading':{"loadingState":"Indlæser...","errorState":"Der er opstået en fejl","_localized":{}}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Annullér","buttonSave":"Gem","itemClose":"Luk","_localized":{}}
});