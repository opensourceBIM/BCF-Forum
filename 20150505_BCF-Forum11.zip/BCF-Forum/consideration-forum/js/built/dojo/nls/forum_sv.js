//>>built
define("dojo/nls/forum_sv",{"dijit/nls/loading":{loadingState:"L\u00e4ser in...",errorState:"Det har intr\u00e4ffat ett fel.",_localized:{}},"dijit/nls/common":{buttonOk:"OK",buttonCancel:"Avbryt",buttonSave:"Spara",itemClose:"St\u00e4ng",_localized:{}}});
//# sourceMappingURL=forum_sv.js.map