define('dojo/nls/forum_pl',{
'dijit/nls/loading':{"loadingState":"Ładowanie...","errorState":"Niestety, wystąpił błąd","_localized":{}}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Anuluj","buttonSave":"Zapisz","itemClose":"Zamknij","_localized":{}}
});