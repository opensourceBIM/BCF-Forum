//>>built
define("dojo/nls/dojo_es-es",{"dijit/nls/loading":{loadingState:"Cargando...",errorState:"Lo siento, se ha producido un error",_localized:{}},"dijit/nls/common":{buttonOk:"Aceptar",buttonCancel:"Cancelar",buttonSave:"Guardar",itemClose:"Cerrar",_localized:{}}});
//# sourceMappingURL=dojo_es-es.js.map