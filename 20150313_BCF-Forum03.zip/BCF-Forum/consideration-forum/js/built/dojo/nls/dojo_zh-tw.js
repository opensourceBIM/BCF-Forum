//>>built
define("dojo/nls/dojo_zh-tw",{"dijit/nls/loading":{loadingState:"\u8f09\u5165\u4e2d...",errorState:"\u62b1\u6b49\uff0c\u767c\u751f\u932f\u8aa4",_localized:{}},"dijit/nls/common":{buttonOk:"\u78ba\u5b9a",buttonCancel:"\u53d6\u6d88",buttonSave:"\u5132\u5b58",itemClose:"\u95dc\u9589",_localized:{}}});
//# sourceMappingURL=dojo_zh-tw.js.map