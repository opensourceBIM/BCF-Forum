//>>built
define("dojo/nls/dojo_fi-fi",{"dijit/nls/loading":{loadingState:"Lataus on meneill\u00e4\u00e4n...",errorState:"On ilmennyt virhe.",_localized:{}},"dijit/nls/common":{buttonOk:"OK",buttonCancel:"Peruuta",buttonSave:"Tallenna",itemClose:"Sulje",_localized:{}}});
//# sourceMappingURL=dojo_fi-fi.js.map