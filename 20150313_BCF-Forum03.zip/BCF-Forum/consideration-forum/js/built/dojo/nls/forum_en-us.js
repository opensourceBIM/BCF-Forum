//>>built
define("dojo/nls/forum_en-us",{"dijit/nls/loading":{loadingState:"Loading...",errorState:"Sorry, an error occurred",_localized:{}},"dijit/nls/common":{buttonOk:"OK",buttonCancel:"Cancel",buttonSave:"Save",itemClose:"Close",_localized:{}}});
//# sourceMappingURL=forum_en-us.js.map