//>>built
define("dojo/nls/dojo_pl",{"dijit/nls/loading":{loadingState:"\u0141adowanie...",errorState:"Niestety, wyst\u0105pi\u0142 b\u0142\u0105d",_localized:{}},"dijit/nls/common":{buttonOk:"OK",buttonCancel:"Anuluj",buttonSave:"Zapisz",itemClose:"Zamknij",_localized:{}}});
//# sourceMappingURL=dojo_pl.js.map