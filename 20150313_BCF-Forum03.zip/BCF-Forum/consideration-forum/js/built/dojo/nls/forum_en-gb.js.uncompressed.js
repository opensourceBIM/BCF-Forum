define('dojo/nls/forum_en-gb',{
'dijit/nls/loading':{"loadingState":"Loading...","errorState":"Sorry, an error occurred","_localized":{}}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Cancel","buttonSave":"Save","itemClose":"Close","_localized":{}}
});