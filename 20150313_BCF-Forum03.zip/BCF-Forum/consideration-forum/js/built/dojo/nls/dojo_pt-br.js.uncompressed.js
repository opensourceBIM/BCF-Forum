define('dojo/nls/dojo_pt-br',{
'dijit/nls/loading':{"loadingState":"Carregando...","errorState":"Desculpe, ocorreu um erro","_localized":{}}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Cancelar","buttonSave":"Salvar","itemClose":"Fechar","_localized":{}}
});