define('dojo/nls/dojo_ko-kr',{
'dijit/nls/loading':{"loadingState":"로드 중...","errorState":"죄송합니다. 오류가 발생했습니다.","_localized":{}}
,
'dijit/nls/common':{"buttonOk":"확인","buttonCancel":"취소","buttonSave":"저장","itemClose":"닫기","_localized":{}}
});