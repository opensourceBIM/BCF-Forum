//>>built
define("dijit/nls/uk/common",{buttonOk:"OK",buttonCancel:"\u0421\u043a\u0430\u0441\u0443\u0432\u0430\u0442\u0438",buttonSave:"\u0417\u0431\u0435\u0440\u0435\u0433\u0442\u0438",itemClose:"\u0417\u0430\u043a\u0440\u0438\u0442\u0438"});
//# sourceMappingURL=common.js.map