//>>built
define("dijit/nls/uk/loading",{loadingState:"\u0417\u0430\u0432\u0430\u043d\u0442\u0430\u0436\u0435\u043d\u043d\u044f...",errorState:"\u0421\u0442\u0430\u043b\u0430\u0441\u044f \u043f\u043e\u043c\u0438\u043b\u043a\u0430"});
//# sourceMappingURL=loading.js.map