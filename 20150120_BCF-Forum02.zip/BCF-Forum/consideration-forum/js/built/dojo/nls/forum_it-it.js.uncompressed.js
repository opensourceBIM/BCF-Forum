define('dojo/nls/forum_it-it',{
'dijit/nls/loading':{"loadingState":"Caricamento in corso...","errorState":"Si è verificato un errore","_localized":{}}
,
'dijit/nls/common':{"buttonOk":"Ok","buttonCancel":"Annulla","buttonSave":"Salva","itemClose":"Chiudi","_localized":{}}
});