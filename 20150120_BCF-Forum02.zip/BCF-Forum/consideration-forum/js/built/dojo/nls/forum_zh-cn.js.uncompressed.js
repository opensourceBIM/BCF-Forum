define('dojo/nls/forum_zh-cn',{
'dijit/nls/loading':{"loadingState":"正在加载...","errorState":"对不起，发生了错误","_localized":{}}
,
'dijit/nls/common':{"buttonOk":"确定","buttonCancel":"取消","buttonSave":"保存","itemClose":"关闭","_localized":{}}
});