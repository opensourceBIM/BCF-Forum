define('dojo/nls/dojo_th',{
'dijit/nls/loading':{"loadingState":"กำลังโหลด...","errorState":"ขออภัย เกิดข้อผิดพลาด","_localized":{}}
,
'dijit/nls/common':{"buttonOk":"ตกลง","buttonCancel":"ยกเลิก","buttonSave":"บันทึก","itemClose":"ปิด","_localized":{}}
});