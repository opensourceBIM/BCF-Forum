define('dojo/nls/forum_nl-nl',{
'dijit/nls/loading':{"loadingState":"Bezig met laden...","errorState":"Er is een fout opgetreden","_localized":{}}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Annuleren","buttonSave":"Opslaan","itemClose":"Sluiten","_localized":{}}
});