//>>built
define("dojo/nls/dojo_pt-pt",{"dijit/nls/loading":{loadingState:"A carregar...",errorState:"Lamentamos, mas ocorreu um erro",_localized:{}},"dijit/nls/common":{buttonOk:"OK",buttonCancel:"Cancelar",buttonSave:"Guardar",itemClose:"Fechar",_localized:{}}});
//# sourceMappingURL=dojo_pt-pt.js.map