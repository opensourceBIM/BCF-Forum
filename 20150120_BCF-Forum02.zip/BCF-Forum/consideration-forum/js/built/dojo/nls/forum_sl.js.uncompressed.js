define('dojo/nls/forum_sl',{
'dijit/nls/loading':{"loadingState":"Nalaganje ...","errorState":"Oprostite, prišlo je do napake.","_localized":{}}
,
'dijit/nls/common':{"buttonOk":"V redu","buttonCancel":"Prekliči","buttonSave":"Shrani","itemClose":"Zapri","_localized":{}}
});