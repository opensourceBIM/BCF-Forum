//>>built
define("dijit/nls/sk/common",{buttonOk:"OK",buttonCancel:"Zru\u0161i\u0165",buttonSave:"Ulo\u017ei\u0165",itemClose:"Zatvori\u0165"});
//# sourceMappingURL=common.js.map