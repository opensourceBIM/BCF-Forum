//>>built
define("dijit/nls/zh/common",{buttonOk:"\u786e\u5b9a",buttonCancel:"\u53d6\u6d88",buttonSave:"\u4fdd\u5b58",itemClose:"\u5173\u95ed"});
//# sourceMappingURL=common.js.map