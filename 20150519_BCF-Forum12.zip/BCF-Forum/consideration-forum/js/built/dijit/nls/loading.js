//>>built
define("dijit/nls/loading",{root:{loadingState:"Loading...",errorState:"Sorry, an error occurred"},zh:!0,"zh-tw":!0,uk:!0,tr:!0,th:!0,sv:!0,sl:!0,sk:!0,ru:!0,ro:!0,pt:!0,"pt-pt":!0,pl:!0,nl:!0,nb:!0,ko:!0,kk:!0,ja:!0,it:!0,id:!0,hu:!0,hr:!0,he:!0,fr:!0,fi:!0,es:!0,el:!0,de:!0,da:!0,cs:!0,ca:!0,bg:!0,az:!0,ar:!0});
//# sourceMappingURL=loading.js.map