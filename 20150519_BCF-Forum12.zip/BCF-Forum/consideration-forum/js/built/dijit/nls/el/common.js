//>>built
define("dijit/nls/el/common",{buttonOk:"\u039f\u039a",buttonCancel:"\u0391\u03ba\u03cd\u03c1\u03c9\u03c3\u03b7",buttonSave:"\u0391\u03c0\u03bf\u03b8\u03ae\u03ba\u03b5\u03c5\u03c3\u03b7",itemClose:"\u039a\u03bb\u03b5\u03af\u03c3\u03b9\u03bc\u03bf"});
//# sourceMappingURL=common.js.map