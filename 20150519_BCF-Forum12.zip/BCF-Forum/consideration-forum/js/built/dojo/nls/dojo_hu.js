//>>built
define("dojo/nls/dojo_hu",{"dijit/nls/loading":{loadingState:"Bet\u00f6lt\u00e9s...",errorState:"Sajn\u00e1lom, hiba t\u00f6rt\u00e9nt",_localized:{}},"dijit/nls/common":{buttonOk:"OK",buttonCancel:"M\u00e9gse",buttonSave:"Ment\u00e9s",itemClose:"Bez\u00e1r\u00e1s",_localized:{}}});
//# sourceMappingURL=dojo_hu.js.map