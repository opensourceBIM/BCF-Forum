define('dojo/nls/forum_tr',{
'dijit/nls/loading':{"loadingState":"Yükleniyor...","errorState":"Üzgünüz, bir hata oluştu","_localized":{}}
,
'dijit/nls/common':{"buttonOk":"Tamam","buttonCancel":"İptal","buttonSave":"Kaydet","itemClose":"Kapat","_localized":{}}
});