//>>built
define("dojo/nls/dojo_sl",{"dijit/nls/loading":{loadingState:"Nalaganje ...",errorState:"Oprostite, pri\u0161lo je do napake.",_localized:{}},"dijit/nls/common":{buttonOk:"V redu",buttonCancel:"Prekli\u010di",buttonSave:"Shrani",itemClose:"Zapri",_localized:{}}});
//# sourceMappingURL=dojo_sl.js.map