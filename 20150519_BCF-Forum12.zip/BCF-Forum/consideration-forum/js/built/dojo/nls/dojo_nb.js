//>>built
define("dojo/nls/dojo_nb",{"dijit/nls/loading":{loadingState:"Laster inn...",errorState:"Det oppsto en feil",_localized:{}},"dijit/nls/common":{buttonOk:"OK",buttonCancel:"Avbryt",buttonSave:"Lagre",itemClose:"Lukk",_localized:{}}});
//# sourceMappingURL=dojo_nb.js.map