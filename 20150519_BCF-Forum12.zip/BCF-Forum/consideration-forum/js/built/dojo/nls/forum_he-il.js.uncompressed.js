define('dojo/nls/forum_he-il',{
'dijit/nls/loading':{"loadingState":"טעינה...‏","errorState":"אירעה שגיאה","_localized":{}}
,
'dijit/nls/common':{"buttonOk":"אישור","buttonCancel":"ביטול","buttonSave":"שמירה","itemClose":"סגירה","_localized":{}}
});