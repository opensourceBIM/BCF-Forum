//>>built
define("dojo/nls/forum_fr-fr",{"dijit/nls/loading":{loadingState:"Chargement...",errorState:"Une erreur est survenue",_localized:{}},"dijit/nls/common":{buttonOk:"OK",buttonCancel:"Annuler",buttonSave:"Enregistrer",itemClose:"Fermer",_localized:{}}});
//# sourceMappingURL=forum_fr-fr.js.map