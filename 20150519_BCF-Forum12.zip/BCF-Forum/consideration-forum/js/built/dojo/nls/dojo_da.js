//>>built
define("dojo/nls/dojo_da",{"dijit/nls/loading":{loadingState:"Indl\u00e6ser...",errorState:"Der er opst\u00e5et en fejl",_localized:{}},"dijit/nls/common":{buttonOk:"OK",buttonCancel:"Annull\u00e9r",buttonSave:"Gem",itemClose:"Luk",_localized:{}}});
//# sourceMappingURL=dojo_da.js.map