//>>built
define("dojo/nls/dojo_ca",{"dijit/nls/loading":{loadingState:"S'est\u00e0 carregant...",errorState:"Ens sap greu. S'ha produ\u00eft un error.",_localized:{}},"dijit/nls/common":{buttonOk:"D'acord",buttonCancel:"Cancel\u00b7la",buttonSave:"Desa",itemClose:"Tanca",_localized:{}}});
//# sourceMappingURL=dojo_ca.js.map