//>>built
define("dojo/nls/dojo_nl-nl",{"dijit/nls/loading":{loadingState:"Bezig met laden...",errorState:"Er is een fout opgetreden",_localized:{}},"dijit/nls/common":{buttonOk:"OK",buttonCancel:"Annuleren",buttonSave:"Opslaan",itemClose:"Sluiten",_localized:{}}});
//# sourceMappingURL=dojo_nl-nl.js.map