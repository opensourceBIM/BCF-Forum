//>>built
define("dijit/nls/sk/loading",{loadingState:"Zav\u00e1dza sa...",errorState:"\u013dutujeme, ale vyskytla sa chyba"});
//# sourceMappingURL=loading.js.map