//>>built
define("dijit/nls/ja/common",{buttonOk:"OK",buttonCancel:"\u30ad\u30e3\u30f3\u30bb\u30eb",buttonSave:"\u4fdd\u5b58",itemClose:"\u9589\u3058\u308b"});
//# sourceMappingURL=common.js.map